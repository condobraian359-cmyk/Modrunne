package com.modrunner.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/** Puente compatible con las WebUI de módulos: ksu.exec(cmd, opciones, nombreCallback). */
class Bridge(private val wv: WebView, private val act: ComponentActivity) {
    private val pool = Executors.newFixedThreadPool(3)

    @JavascriptInterface
    fun exec(cmd: String, options: String?, callback: String) {
        pool.execute {
            val r = Sh.run(cmd, 60000)
            val js = "try{window[" + JSONObject.quote(callback) + "](" + r.code + "," +
                JSONObject.quote(r.out) + "," + JSONObject.quote(r.err) + ")}catch(e){}"
            wv.post { wv.evaluateJavascript(js, null) }
        }
    }

    @JavascriptInterface
    fun toast(msg: String) {
        act.runOnUiThread { Toast.makeText(act, msg, Toast.LENGTH_SHORT).show() }
    }
}

class WebUiActivity : ComponentActivity() {
    private lateinit var wv: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        if (id == null) { finish(); return }
        title = intent.getStringExtra("name") ?: id

        wv = WebView(this)
        wv.setBackgroundColor(Color.parseColor("#070B14"))
        setContentView(wv)

        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = true
        wv.settings.allowContentAccess = false
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.scheme != "file"   // solo páginas del propio módulo
        }
        val bridge = Bridge(wv, this)
        wv.addJavascriptInterface(bridge, "ksu")
        wv.addJavascriptInterface(bridge, "Axeron")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (wv.canGoBack()) wv.goBack() else finish()
            }
        })

        thread {
            val root = Modules.prepareWeb(this, id)
            runOnUiThread {
                if (root == null) {
                    Toast.makeText(this, "Este módulo no tiene WebUI (falta index.html)", Toast.LENGTH_LONG).show()
                    finish()
                } else {
                    wv.loadUrl("file://" + File(root, "index.html").absolutePath)
                }
            }
        }
    }

    override fun onDestroy() {
        wv.destroy()
        super.onDestroy()
    }
}
