package com.modrunner.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private var backend by mutableStateOf(Backend.NONE)
    private var shizukuAlive by mutableStateOf(false)
    private val mods = mutableStateListOf<Mod>()
    private var busy by mutableStateOf(false)
    private var dialog by mutableStateOf<String?>(null)

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
    private val binderListener = Shizuku.OnBinderReceivedListener { refresh() }
    private val deadListener = Shizuku.OnBinderDeadListener { refresh() }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) doInstall(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 5)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    private fun refresh(forceRoot: Boolean = false) {
        thread {
            if (forceRoot) Sh.rootAvailable(true)
            val b = Sh.backend()
            val alive = Sh.shizukuAlive()
            val l = if (b != Backend.NONE) Modules.list() else emptyList()
            runOnUiThread {
                backend = b
                shizukuAlive = alive
                mods.clear()
                mods.addAll(l)
            }
        }
    }

    private fun work(block: () -> String) {
        busy = true
        thread {
            val msg = try { block() } catch (e: Throwable) { "Error: ${e.message}" }
            runOnUiThread {
                busy = false
                if (msg.isNotBlank()) dialog = msg
            }
            refresh()
        }
    }

    private fun doInstall(uri: Uri) = work {
        val id = Modules.install(this, uri)
        val st = Modules.start(id)
        "Módulo instalado: $id\n$st"
    }

    private fun hint(): String = when {
        backend == Backend.SHIZUKU -> "Listo: los módulos se ejecutan con permisos de shell."
        backend == Backend.ROOT -> "Listo: los módulos se ejecutan como root."
        shizukuAlive -> "Shizuku está activo pero falta darle permiso a esta app."
        else -> "Inicia Shizuku (o usa root) para poder instalar y ejecutar módulos."
    }

    @Composable
    private fun Screen() {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("ModRunner", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("Acceso: ${backend.label}", fontWeight = FontWeight.Bold)
                    Text(hint(), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (shizukuAlive && backend != Backend.SHIZUKU) {
                            Button(onClick = { Shizuku.requestPermission(1001) }) { Text("Dar permiso") }
                        }
                        OutlinedButton(onClick = { refresh(true) }) { Text("Actualizar") }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { picker.launch(arrayOf("*/*")) },
                enabled = !busy && backend != Backend.NONE,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Instalar módulo (.zip)") }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp))
            Spacer(Modifier.height(10.dp))
            if (mods.isEmpty()) {
                Text("No hay módulos instalados.", style = MaterialTheme.typography.bodyMedium)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(mods, key = { it.id }) { m -> ModCard(m) }
            }
        }
        val d = dialog
        if (d != null) {
            AlertDialog(
                onDismissRequest = { dialog = null },
                confirmButton = { TextButton(onClick = { dialog = null }) { Text("Cerrar") } },
                text = { Text(d, modifier = Modifier.verticalScroll(rememberScrollState())) }
            )
        }
    }

    @Composable
    private fun ModCard(m: Mod) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name + if (m.version.isNotEmpty()) "  v${m.version}" else "", fontWeight = FontWeight.Bold)
                        if (m.author.isNotEmpty()) Text("por ${m.author}", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = m.enabled, enabled = !busy, onCheckedChange = { on -> work { Modules.setEnabled(m.id, on); "" } })
                }
                if (m.description.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(m.description, style = MaterialTheme.typography.bodySmall, maxLines = 3)
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (m.hasWeb) TextButton(onClick = {
                        startActivity(Intent(this@MainActivity, WebUiActivity::class.java).putExtra("id", m.id).putExtra("name", m.name))
                    }) { Text("WebUI") }
                    if (m.hasAction) TextButton(enabled = !busy, onClick = { work { Modules.runAction(m.id) } }) { Text("Acción") }
                    TextButton(enabled = !busy, onClick = { work { Modules.uninstall(m.id).ifBlank { "Módulo desinstalado" } } }) { Text("Desinstalar") }
                }
            }
        }
    }
}
