package com.modrunner.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class ShResult(val code: Int, val raw: ByteArray, val err: String) {
    val out: String get() = String(raw, Charsets.UTF_8)
}

enum class Backend(val label: String) {
    SHIZUKU("Shizuku (sin root)"),
    ROOT("Root"),
    NONE("Sin acceso")
}

/** Ejecuta comandos con el mejor acceso disponible: Shizuku, root o shell normal (limitado). */
object Sh {
    @Volatile private var rootOk: Boolean? = null

    /** Entrecomilla un texto para el shell. */
    fun q(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    fun shizukuAlive(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun shizukuGranted(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun rootAvailable(force: Boolean = false): Boolean {
        if (!force) rootOk?.let { return it }
        val ok = try {
            val p = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
            val finished = p.waitFor(5, TimeUnit.SECONDS)
            val text = if (finished) p.inputStream.bufferedReader().readText() else { p.destroy(); "" }
            finished && text.contains("uid=0")
        } catch (e: Throwable) { false }
        rootOk = ok
        return ok
    }

    fun backend(): Backend = when {
        shizukuGranted() -> Backend.SHIZUKU
        rootAvailable() -> Backend.ROOT
        else -> Backend.NONE
    }

    private fun start(cmd: String): Process = when (backend()) {
        Backend.SHIZUKU -> {
            // newProcess es privado desde Shizuku 13.1: se llama por reflexión
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        }
        Backend.ROOT -> ProcessBuilder("su", "-c", cmd).start()
        Backend.NONE -> ProcessBuilder("sh", "-c", cmd).start()
    }

    fun run(cmd: String, timeoutMs: Long = 30000, stdin: InputStream? = null): ShResult {
        return try {
            val p = start(cmd)
            val outB = ByteArrayOutputStream()
            val errB = ByteArrayOutputStream()
            val t1 = thread { try { p.inputStream.copyTo(outB) } catch (_: Throwable) {} }
            val t2 = thread { try { p.errorStream.copyTo(errB) } catch (_: Throwable) {} }
            if (stdin != null) {
                try { p.outputStream.use { stdin.copyTo(it) } } catch (_: Throwable) {}
            } else {
                try { p.outputStream.close() } catch (_: Throwable) {}
            }
            val done = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
            if (!done) p.destroy()
            t1.join(2000)
            t2.join(2000)
            ShResult(if (done) p.exitValue() else -2, outB.toByteArray(), String(errB.toByteArray(), Charsets.UTF_8))
        } catch (e: Throwable) {
            ShResult(-1, ByteArray(0), e.message ?: "error")
        }
    }

    /** Escribe un archivo con el acceso actual (el shell no puede leer la carpeta privada de la app). */
    fun writeFile(path: String, input: InputStream): ShResult =
        run("mkdir -p \"\$(dirname ${q(path)})\" && cat > ${q(path)}", 60000, input)
}
