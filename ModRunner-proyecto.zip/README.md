# ModRunner

App Android para instalar y usar módulos tipo AxManager (por ejemplo AI-Auto-Mode) sin root, usando Shizuku. También funciona con root.

## Qué hace
- Instala módulos desde un `.zip` (con `module.prop`; `service.sh`, `action.sh`, `uninstall.sh` y `webroot/` son opcionales).
- Activa/desactiva cada módulo, ejecuta su botón Acción y lo desinstala (ejecuta su `uninstall.sh`).
- Abre la WebUI del módulo. El puente `ksu.exec` / `Axeron.exec` es compatible con la WebUI de AI-Auto-Mode.
- Al arrancar el teléfono inicia los módulos activados, cuando Shizuku o root ya estén disponibles.

Los módulos se guardan en `/data/local/tmp/modrunner/modules/<id>/`.

## Compilar sin PC (desde el celular)
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta.
2. Entra en la pestaña **Actions** → **Compilar APK** → **Run workflow**.
3. Cuando termine (unos 5-8 min), descarga el artefacto **ModRunner-debug-apk** e instala el APK.

## Compilar con Android Studio
Abre la carpeta, deja que sincronice Gradle y ejecuta **Build → Build APK(s)**.

## Usar
1. Instala Shizuku y arráncalo (depuración inalámbrica o root).
2. Abre ModRunner → **Dar permiso**.
3. **Instalar módulo (.zip)** y elige el zip del módulo.

## Límites conocidos
- Sin Shizuku ni root la app no puede instalar ni ejecutar módulos.
- Tras reiniciar, Shizuku debe volver a arrancar (con root lo hace solo; con depuración inalámbrica hay que iniciarlo a mano). Hasta entonces los módulos no se inician.
- No ejecuta `customize.sh`/`install.sh` de módulos tipo Magisk ni modifica el sistema de archivos del sistema (no hay montaje overlay).
- El formato de módulo de AxManager original puede tener diferencias; ModRunner soporta lo descrito arriba.
