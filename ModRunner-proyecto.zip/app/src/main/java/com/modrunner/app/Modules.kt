package com.modrunner.app

import android.content.Context
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream

const val BASE = "/data/local/tmp/modrunner/modules"
private val ID_RE = Regex("[A-Za-z0-9_.-]+")

data class Mod(
    val id: String,
    val dir: String,
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val enabled: Boolean,
    val hasWeb: Boolean,
    val hasAction: Boolean
)

object Modules {
    private val q = Sh::q

    fun dir(id: String) = "$BASE/$id"

    // El truco del corchete evita que pkill/pgrep se encuentren a sí mismos
    private fun pattern(id: String) = "[m]odrunner/modules/" + id.replace(".", "\\.") + "/service\\.sh"

    fun list(): List<Mod> {
        val cmd = "for d in $BASE/*/; do [ -f \"\${d}module.prop\" ] || continue; " +
            "echo \"@@\${d%/}\"; cat \"\${d}module.prop\"; echo; " +
            "[ -f \"\${d}disable\" ] && echo \"__disabled=1\"; " +
            "[ -d \"\${d}webroot\" ] && echo \"__web=1\"; " +
            "[ -f \"\${d}action.sh\" ] && echo \"__action=1\"; done; true"
        val res = Sh.run(cmd)
        val mods = ArrayList<Mod>()
        var dir: String? = null
        var props = HashMap<String, String>()
        fun flush() {
            val d = dir ?: return
            val id = d.substringAfterLast('/')
            mods.add(
                Mod(
                    id, d,
                    props["name"] ?: id,
                    props["version"] ?: "",
                    props["author"] ?: "",
                    props["description"] ?: "",
                    props["__disabled"] != "1",
                    props["__web"] == "1",
                    props["__action"] == "1"
                )
            )
        }
        for (line in res.out.lines()) {
            val l = line.trimEnd('\r')
            if (l.startsWith("@@")) {
                flush()
                dir = l.substring(2)
                props = HashMap()
            } else {
                val i = l.indexOf('=')
                if (i > 0) props[l.substring(0, i).trim()] = l.substring(i + 1).trim()
            }
        }
        flush()
        return mods
    }

    /** Instala un .zip (module.prop en la raíz o dentro de una sola carpeta). Devuelve el id. */
    fun install(ctx: Context, uri: Uri): String {
        val cr = ctx.contentResolver
        var bestName: String? = null
        var bestProp: String? = null
        (cr.openInputStream(uri) ?: error("No se pudo abrir el archivo")).use { ins ->
            ZipInputStream(ins).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name
                    if (!e.isDirectory && (n == "module.prop" || n.endsWith("/module.prop"))) {
                        val depth = n.count { it == '/' }
                        val cur = bestName
                        if (cur == null || depth < cur.count { it == '/' }) {
                            bestName = n
                            bestProp = String(z.readBytes(), Charsets.UTF_8)
                        }
                    }
                    e = z.nextEntry
                }
            }
        }
        val name = bestName ?: error("El zip no tiene module.prop")
        val prop = bestProp ?: error("El zip no tiene module.prop")
        val prefix = name.substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }
        val id = prop.lines().map { it.trim() }.firstOrNull { it.startsWith("id=") }
            ?.substringAfter('=')?.trim()
        if (id == null || !ID_RE.matches(id)) error("module.prop sin un id válido (solo letras, números, . _ -)")

        val dir = dir(id)
        stop(id)
        val clean = Sh.run("rm -rf ${q(dir)} && mkdir -p ${q(dir)}")
        if (clean.code != 0) error("No se pudo preparar $dir: ${clean.err}")

        (cr.openInputStream(uri) ?: error("No se pudo abrir el archivo")).use { ins ->
            ZipInputStream(ins).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name
                    if (!e.isDirectory && n.startsWith(prefix)) {
                        val rel = n.removePrefix(prefix)
                        val bad = rel.isEmpty() || rel.startsWith("/") || rel.contains("..") || rel.startsWith("META-INF/")
                        if (!bad) {
                            val r = Sh.writeFile("$dir/$rel", ByteArrayInputStream(z.readBytes()))
                            if (r.code != 0) error("Falló al copiar $rel: ${r.err}")
                        }
                    }
                    e = z.nextEntry
                }
            }
        }
        Sh.run("chmod -R 755 ${q(dir)}")
        return id
    }

    fun isRunning(id: String): Boolean =
        Sh.run("pgrep -f ${q(pattern(id))} >/dev/null 2>&1 && echo yes || echo no").out.trim() == "yes"

    fun start(id: String): String {
        val dir = dir(id)
        val svc = q("$dir/service.sh")
        val cmd = "[ -f $svc ] || { echo 'Este módulo no tiene service.sh'; exit 0; }; " +
            "if pgrep -f ${q(pattern(id))} >/dev/null 2>&1; then echo 'Ya estaba activo'; else " +
            "S=\"\"; command -v setsid >/dev/null 2>&1 && S=setsid; " +
            "(\$S nohup sh $svc >/dev/null 2>&1 &); echo 'Iniciado'; fi"
        return Sh.run(cmd, 15000).out.trim()
    }

    fun stop(id: String) {
        Sh.run("pkill -f ${q(pattern(id))}; true", 15000)
    }

    fun setEnabled(id: String, enabled: Boolean) {
        val dir = dir(id)
        if (enabled) {
            Sh.run("rm -f ${q("$dir/disable")}")
            start(id)
        } else {
            Sh.run("touch ${q("$dir/disable")}")
            stop(id)
        }
    }

    fun runAction(id: String): String {
        val r = Sh.run("sh ${q(dir(id) + "/action.sh")} 2>&1", 60000)
        return r.out.trim().ifEmpty { "(sin salida, código ${r.code})" }
    }

    fun uninstall(id: String): String {
        val dir = dir(id)
        val r = Sh.run("[ -f ${q("$dir/uninstall.sh")} ] && sh ${q("$dir/uninstall.sh")} 2>&1; true", 60000)
        stop(id)
        Sh.run("rm -rf ${q(dir)}")
        return r.out.trim()
    }

    /** Copia el webroot a la carpeta privada de la app para poder abrirlo en un WebView. */
    fun prepareWeb(ctx: Context, id: String): File? {
        val root = File(ctx.filesDir, "webui/$id")
        root.deleteRecursively()
        root.mkdirs()
        val web = "${dir(id)}/webroot"
        val files = Sh.run("cd ${q(web)} && find . -type f").out.lines().map { it.trim() }.filter { it.isNotEmpty() }
        for (rel in files) {
            val r = rel.removePrefix("./")
            if (r.contains("..")) continue
            val f = File(root, r)
            f.parentFile?.mkdirs()
            f.writeBytes(Sh.run("cat ${q("$web/$r")}", 30000).raw)
        }
        return if (File(root, "index.html").exists()) root else null
    }
}
