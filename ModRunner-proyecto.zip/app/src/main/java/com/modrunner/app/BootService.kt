package com.modrunner.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat
import kotlin.concurrent.thread

/** Al arrancar el teléfono espera a tener acceso (Shizuku o root) y inicia los módulos activados. */
class BootService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("boot", "Arranque de módulos", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "boot")
            .setContentTitle("ModRunner")
            .setContentText("Iniciando módulos…")
            .setSmallIcon(R.drawable.ic_launcher)
            .build()
        ServiceCompat.startForeground(this, 7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST)

        thread {
            var tries = 0
            while (Sh.backend() == Backend.NONE && tries < 40) {
                Thread.sleep(3000)
                tries++
                if (tries % 5 == 0) Sh.rootAvailable(true)
            }
            if (Sh.backend() != Backend.NONE) {
                for (m in Modules.list()) if (m.enabled) Modules.start(m.id)
            }
            stopSelf()
        }
        return START_NOT_STICKY
    }
}
